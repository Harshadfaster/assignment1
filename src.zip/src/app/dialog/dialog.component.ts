import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  patientForm ! : FormGroup;
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.patientForm = this.formBuilder.group({
      patientName:['',Validators.required],
      dateOfBirth:['',Validators.required],
      phoneNumber:['',Validators.required],
      zipCode:['',Validators.required],

    })
  }

  addPatient(){
    console.log(this.patientForm.value);
  }

}

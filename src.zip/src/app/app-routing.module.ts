import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { SurgeriesComponent } from './surgeries/surgeries.component';
import { TemplatesComponent } from './templates/templates.component';
import { DialogComponent } from './dialog/dialog.component';



const routes: Routes = [

  {path:'', component: DashboardComponent,
    children:[
      { path:'dashboard', component:DashboardComponent},
      { path:'notifications', component:NotificationsComponent},
      { path:'surgeries', component:SurgeriesComponent},
      { path:'templates', component:TemplatesComponent},
      { path:'dialog', component:DialogComponent}
    ]
  },

  
  
]


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
